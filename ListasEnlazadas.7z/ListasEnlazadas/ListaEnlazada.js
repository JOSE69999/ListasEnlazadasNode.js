class Nodo {
    constructor(dato, enlace = null) {
        this.dato = dato;
        this.enlace = enlace;
    }

    toString() {
        return `${this.dato} => ${this.enlace}`;
    }

    leerDato() {
        return this.dato;
    }

    siguiente() {
        return this.enlace;
    }
}

// Código de la clase Lista
class Lista {
    constructor() {
        this.primero = null;
    }

    leerPrimero() {
        return this.primero;
    }

    insertarCabezaLista(entrada) {
        const nuevo = new Nodo(entrada, this.primero);
        this.primero = nuevo;
    }

    insertarLista(anterior, entrada) {
        if (anterior === null) return;
        const nuevo = new Nodo(entrada, anterior.enlace);
        anterior.enlace = nuevo;
    }

    eliminar(entrada) {
        let actual = this.primero;
        let anterior = null;
        while (actual !== null && actual.dato !== entrada) {
            anterior = actual;
            actual = actual.enlace;
        }
        if (actual !== null) {
            if (actual === this.primero) {
                this.primero = actual.enlace;
            } else {
                anterior.enlace = actual.enlace;
            }
        }
    }

    buscarLista(destino) {
        let indice = this.primero;
        while (indice !== null) {
            if (indice.dato === destino) {
                return indice;
            }
            indice = indice.enlace;
        }
        return null;
    }

    visualizar() {
        let n = this.primero;
        const elementos = [];
        while (n !== null) {
            elementos.push(n.dato);
            n = n.enlace;
        }
        console.log(elementos.join(' '));
    }

    toString() {
        return `=> ${this.primero}`;
    }

    // Método para invertir la lista enlazada
    invertir() {
        let prev = null;
        let actual = this.primero;
        let siguiente = null;

        while (actual !== null) {
            siguiente = actual.enlace;
            actual.enlace = prev;
            prev = actual;
            actual = siguiente;
        }

        this.primero = prev;
    }

    // Método para eliminar duplicados de la lista
    eliminarDuplicados() {
        let actual = this.primero;
        let valores = new Set();
        let anterior = null;

        while (actual !== null) {
            if (valores.has(actual.dato)) {
                anterior.enlace = actual.enlace;
            } else {
                valores.add(actual.dato);
                anterior = actual;
            }
            actual = actual.enlace;
        }
    }

    // Método para obtener el n-ésimo elemento desde el final
    obtenerDesdeElFinal(n) {
        let primero = this.primero;
        let segundo = this.primero;

        // Mover el segundo puntero n pasos adelante
        for (let i = 0; i < n; i++) {
            if (segundo === null) return null;  // Si n es mayor que el tamaño de la lista
            segundo = segundo.enlace;
        }

        // Ahora mover ambos punteros hasta que el segundo llegue al final
        while (segundo !== null) {
            primero = primero.enlace;
            segundo = segundo.enlace;
        }

        return primero ? primero.dato : null;
    }
}

// === PRUEBAS AUTOMÁTICAS ===
console.log("\n🔍 Ejecutando pruebas automáticas...\n");

const testLista = new Lista();
testLista.insertarCabezaLista(5);
testLista.insertarCabezaLista(4);
testLista.insertarCabezaLista(3);
testLista.insertarCabezaLista(2);
testLista.insertarCabezaLista(1);

// Mostrar lista antes de la prueba del segundo desde el final
console.log("Lista antes de la prueba de 'segundo desde el final':");
testLista.visualizar();

// Prueba: Obtener el 2° elemento desde el final
console.assert(testLista.obtenerDesdeElFinal(2) === 4, "❌ ERROR: El segundo elemento desde el final debería ser 4");

console.log("\n✅ Todas las pruebas pasaron correctamente.");
